# coding:utf-8
# 作者：小狐狸狗狗
# 时间：2020年05月27日10:58:55
# 功能：遍历指定目录下的所有Json文件，统计所有出现的字符并输出（剪裁ttf字体使用）

import sys
import os
import re
import json
import datetime

# 根目录
gPath = ""
# 存放所有字符的字典
gCharDict = {}

# 常亮
CONST = {
    "EXT": {".json"}, # 所需的文件后缀，目前只支持json格式
    "SAVE_FILE_NAME": "chars.txt", # 最后保存的文件名
    "IGNORE": ["{", "}"], #忽略的字符
}

from optparse import OptionParser

#获取运行目录
def getRunPath():
   return os.path.split(os.path.realpath(__file__))[0]

# 获取所有json文件
def getAllJson():

    print("开始执行")
    for maindir, subdir, file_name_list in os.walk(gPath):
        for filename in file_name_list:

            filePath = os.path.join(maindir, filename)
            ext = os.path.splitext(filePath)[1]

            if ext in CONST["EXT"]:
                print("解析文件:{}".format(filePath))
                parseJsonFile(filePath)

    saveCharDict()

# 解析Json文件
def parseJsonFile(filePath):
    fileObj = open(filePath,"r",encoding='UTF-8')
    fileContent = fileObj.read()

    # json转python dict
    dataDict = json.loads(fileContent)
    foreachDict(dataDict)

# 遍历dict
def foreachDict(data):

    for key in data:

        now = data[key]
        nowType = type(now)

        if nowType is dict:
            foreachDict(now)
        # 目前工具打出的不会是list
        elif nowType is list:
            pass
        else:
            strData = str(now)
            getCharFromStr(strData)

# 获取字符串中的每个文字
def getCharFromStr(strData):
    # print("***************我是分隔符***************")
    # print(strData)

    global gCharDict

    for i in range(0, len(strData)):
        if strData[i] not in CONST["IGNORE"]:
            gCharDict[strData[i]] = 1

# 保存数据
def saveCharDict():

    finalStr = "" # 保存的字符串
    global gCharDict # 汇总的字符
    sortCharDict = sorted(gCharDict.items(), key = lambda  x: x[0]) # 汇总的字符排下序

    # 拼成最终保存的字符串
    for i in range(0, len(sortCharDict)):
        finalStr += sortCharDict[i][0]

    # 保存文件
    savePath = getRunPath() + "/" + CONST["SAVE_FILE_NAME"]

    file = open(savePath, "w")
    file.write(finalStr)
    file.close()

    print("\n忽略的字符列表为:{0} 如需修改请在CONST[\"IGNORE\"]中替换".format(str(CONST["IGNORE"])))
    print("文件保存路径：{}".format(savePath))
    print("汪~生成完毕快去查看吧^_^")

if __name__ == '__main__':

    # 进行参数解析
    parser = OptionParser()

    parser.add_option(
        "--path",
        action="store",
        dest="path",
        help="解析json文件的根目录"
    )

    (opts, args) = parser.parse_args()

    gPath = opts.path

    getAllJson()